package entity;

public enum InternshipStatus {
	PENDING,
	APPROVED,
	REJECTED,
	CLOSED,
	FILLED;

}
