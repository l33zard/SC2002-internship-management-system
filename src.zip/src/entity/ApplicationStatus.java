package entity;

public enum ApplicationStatus {
	PENDING,
	SUCCESSFUL,
	UNSUCCESSFUL,
	WITHDRAWN
}
