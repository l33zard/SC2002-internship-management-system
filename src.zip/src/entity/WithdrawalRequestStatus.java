package entity;

public enum WithdrawalRequestStatus {
	PENDING,
	APPROVED,
	REJECTED
}
